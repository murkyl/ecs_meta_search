Authors
=======

Flask-WTF is created by Dan Jacob, and now is maintained by Hsiaoming Yang.

Contributors
------------

People who send patches and suggestions:

.. include:: ../AUTHORS

Find more contributors on GitHub_.

.. _GitHub: http://github.com/lepture/flask-wtf/contributors
