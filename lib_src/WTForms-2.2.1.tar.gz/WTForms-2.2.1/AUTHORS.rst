WTForms is developed and maintained by the WTForms team and community
contributors. It was originally created in 2008 by James Crasta and
Thomas Johansson. The core maintainers are:

-   David Lord (davidism)

A full list of contributors is available from git with::

    git shortlog -sne
